﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using WorkshopPizzaApp.Data.Model;

namespace WorkshopPizzaApp.Data
{
    public class PizzaAppDbContext : DbContext
    {
        public DbSet<PizzaModel> Pizzas { get; set; }

        public DbSet<SizeModel> Sizes { get; set; }

        public DbSet<OrderModel> Orders { get; set; }

        public DbSet<UserModel> Users { get; set; }

        public DbSet<PizzaSizeModel> PizzaSizes { get; set; }

        public DbSet<PizzaOrderModel> PizzaOrders { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"data source=DESKTOP-CO6AHNV\SQLEXPRESS; initial catalog=PizzaAppDB;Integrated Security=True;");
        }
    }
}
